﻿
Partial Class Propuestas
    Inherits System.Web.UI.Page

End Class
